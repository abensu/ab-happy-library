var My = {
    name    : 'Kitty'
    , say   : function ( name ) {
        alert( name || this.name );
    }
};