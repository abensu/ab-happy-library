declare namespace My {

    let name: string;

    function say( name?: string ): void;
}